
function startGame() {
  alert('Das Spiel beginnt! Ziehe deine erste Karte...');
}
